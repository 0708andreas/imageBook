from PIL import Image, ImageDraw
import math
import random

blockSize = 16
blockHeight = 16
blockWidth = 16

matchType = 0;
# 0 = random
# 1 = select best
# 2 = iterate

seed = -1
imgHeight = -1

def colorFilter(img, colorTo):
	pix = img.load()
	coordX = -1
	coordY = 0
	sizeX = img.size[0]
	size = img.size[0] * img.size[1]
	for x in range(size):
		coordX = coordX + 1
		if coordX >= sizeX:
			coordY = coordY + 1
			coordX = 0
		p = pix[coordX, coordY]
		
		color = ((colorTo[0] + p[0]) / 2, (colorTo[1] + p[1]) / 2, (colorTo[2] + p[2]) / 2)
		
		pix[coordX, coordY] = color

def averageColor(img):
	pix = img.load()
	coordX = -1
	coordY = 0
	sizeX = img.size[0]
	size = img.size[0] * img.size[1]
	red = []
	green = []
	blue = []
	for x in range(size):
		coordX = coordX + 1
		if coordX >= sizeX:
			coordY = coordY + 1
			coordX = 0
		p = pix[coordX, coordY]
		red.append(p[0])
		green.append(p[1])
		blue.append(p[2])
	return (sum(red) / len(red), sum(green) / len(green), sum(blue) / len(blue))

def generateImage(img, listOfImages):
	for listIndex, listImg in enumerate(listOfImages):
		listOfImages[listIndex] = listImg.resize((blockSize, blockSize))
	prefWidth = img.size[0]
	prefHeight = img.size[1]
	prefWidth = int(math.floor(prefWidth / blockSize) * blockSize)
	prefHeight = int(math.floor(prefHeight / blockSize) * blockSize)
	img = img.crop((0, 0, prefWidth, prefHeight))
	blockCount = (prefWidth / blockSize) * (prefHeight / blockSize)
	blocksX = prefWidth / blockSize;
	coordX = -1
	coordY = 0
	listIndex = -1
	foundColors = {}
	blockList = []
	
	if matchType == 1: #Find best color-matching image in list
	#TODO: make this work
		for x in range(blockCount):
			coordX = coordX + 1
			listIndex = listIndex + 1
			if coordX >= blocksX:
				coordY = coordY + 1
				coordX = 0
			if listIndex >= len(listOfImages):
				listIndex = 0
			rect = (coordX * blockSize, coordY * blockSize, coordX * blockSize + blockSize, coordY * blockSize + blockSize)
			block = img.crop(rect)
			blockColor = averageColor(block)
			if blockColor[0] >= 250 and blockColor[1] >= 250 and blockColor[2] >= 250:
				continue
			newBlock = listOfImages[listIndex].copy()
			colorFilter(newBlock, blockColor)
			img.paste(newBlock, rect)
		return img

	if matchType == 0 or matchType == 2: #Loop through the list or pick a random
		if not seed == -1:
			random.seed(seed)
		for x in range(blockCount):
			coordX = coordX + 1
			listIndex = listIndex + 1
			if coordX >= blocksX:
				coordY = coordY + 1
				coordX = 0
			if listIndex >= len(listOfImages):
				listIndex = 0
			rect = (coordX * blockSize, coordY * blockSize, coordX * blockSize + blockSize, coordY * blockSize + blockSize)
			block = img.crop(rect)
			blockColor = averageColor(block)
			if blockColor[0] >= 250 and blockColor[1] >= 250 and blockColor[2] >= 250:
				continue
			if matchType == 0: #Pick a random
				newBlock = listOfImages[random.randrange(0, len(listOfImages))].copy()
			else:
				newBlock = listOfImages[listIndex].copy()
			colorFilter(newBlock, blockColor)
			img.paste(newBlock, rect)
		return img


